/**
出力する内容が違う．
繰り返し制御文を使っていない．
*/

#include <stdio.h>

int main() {
  printf("Hello world!\n");
  printf("Hello world!\n");
  printf("Hello world!\n");
  printf("Hello world!\n");
  printf("Hello world!\n");
  printf("Hello Hirodai!\n");
  return 0;
}
